/* eslint-disable react-refresh/only-export-components */
import { createContext, useContext, useState, useEffect, useMemo, useCallback, useRef } from "react";
import { storage, STORAGE_KEYS } from "../utils/storage";
import { SEED_POSTS } from "../data/seedData";
import { generateId } from "../utils/id";
import { useAuth } from "./AuthContext";
import { useToast } from "./ToastContext";
import { api } from "../services/api";

const BlogContext = createContext();

export function BlogProvider({ children }) {
  const { currentUser, users } = useAuth();
  const { addToast } = useToast();

  // Hàm kiểm tra quyền Ban giám sát / Quản trị viên (Admin & Moderator)
  const checkIsSupervisor = (user) => {
    if (!user) return false;
    return Boolean(
      user.role === "admin" ||
      user.role === "moderator" ||
      user.is_superuser ||
      user.id === "demo_admin" ||
      user.id === "demo_moderator" ||
      String(user.id) === "1" ||
      String(user.id) === "11" ||
      user.email === "admin@itblog.dev" ||
      user.email === "mod@itblog.dev" ||
      user.username === "admin" ||
      user.username === "mod_dev" ||
      (Array.isArray(user.roles) && (
        user.roles.includes("admin") ||
        user.roles.includes("moderator") ||
        user.roles.some((r) =>
          typeof r === "string" ? r === "admin" || r === "moderator" : r?.name === "admin" || r?.name === "moderator"
        )
      ))
    );
  };

  // Khởi tạo danh sách bài viết từ storage hoặc seed data
  const [posts, setPosts] = useState(() => {
    const saved = storage.get(STORAGE_KEYS.POSTS, null);
    if (Array.isArray(saved) && saved.length >= 5 && saved.some((p) => String(p.id) === "9")) {
      return saved;
    }
    storage.set(STORAGE_KEYS.POSTS, SEED_POSTS);
    return SEED_POSTS;
  });

  const syncInFlight = useRef(false);
  const syncRequested = useRef(false);

  // Tự động tải và đồng bộ danh sách bài viết từ backend FastAPI
  const syncPostsFromBackend = useCallback(() => {
    if (syncInFlight.current) {
      syncRequested.current = true;
      return;
    }
    syncInFlight.current = true;

    const fetchAllPosts = async (status) => {
      const firstPage = await api.posts.list({ page: 1, limit: 500, ...status });
      const toItems = (response) => response?.items || (Array.isArray(response) ? response : []);
      const items = toItems(firstPage);
      const totalPages = firstPage?.total_pages || 1;
      const rest = await Promise.all(
        Array.from({ length: Math.max(0, totalPages - 1) }, (_, index) =>
          api.posts.list({ page: index + 2, limit: 500, ...status }).then(toItems)
        )
      );
      return [...items, ...rest.flat()];
    };

    Promise.all([
      fetchAllPosts({}),
      fetchAllPosts({ status: "pending" }).catch((error) => {
        console.warn("Could not sync pending posts:", error.message);
        return [];
      })
    ])
      .then(([approvedItems, pendingItems]) => {
        // Người dùng thường không có quyền xem pending; backend có thể trả approved ở request này.
        // Gộp theo ID để tránh trùng bài.
        const backendItems = new Map(
          [...approvedItems, ...pendingItems].map((post) => [String(post.id), post])
        );
        const normalized = [...backendItems.values()].map((bp) => ({
          id: String(bp.id),
          title: bp.title,
          slug: bp.slug,
          category: bp.category?.name || bp.category || "Backend",
          tags: Array.isArray(bp.tags) ? bp.tags.map((t) => (typeof t === "object" ? t.name : t)) : [],
          coverImage: bp.cover_image || bp.coverImage || "",
          excerpt: bp.excerpt || "",
          content: bp.content || "",
          authorId: bp.author_id || bp.author?.id || "author_unknown",
          author: bp.author ? {
            id: String(bp.author.id),
            name: bp.author.name || bp.author.username || "Tác giả IT",
            username: bp.author.username,
            avatar: bp.author.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${bp.author.id}`,
            bio: bp.author.bio || "Cộng tác viên IT Blog",
            role: bp.author.role || "user"
          } : null,
          status: bp.status || "approved",
          likes_count: bp.likes_count ?? (Array.isArray(bp.likes) ? bp.likes.length : 0),
          likes: Array.isArray(bp.likes) ? bp.likes : [],
          bookmarks_count: bp.bookmarks_count ?? (Array.isArray(bp.bookmarks) ? bp.bookmarks.length : 0),
          bookmarks: Array.isArray(bp.bookmarks) ? bp.bookmarks : [],
          comments_count: bp.comments_count ?? (Array.isArray(bp.comments) ? bp.comments.length : undefined),
          comments: Array.isArray(bp.comments) && typeof bp.comments[0] === "object" ? bp.comments : undefined,
          views: typeof bp.views === "number" ? bp.views : (bp.views || 0),
          readTime: bp.read_time || "5 phút đọc",
          isVerified: Boolean(bp.is_verified || bp.isVerified),
          createdAt: bp.created_at || bp.createdAt || new Date().toISOString()
        }));

        setPosts((prev) => {
          const backendIds = new Set(normalized.map((post) => post.id));
          const previousById = new Map(prev.map((post) => [String(post.id), post]));
          const pendingLocal = prev.filter(
            (post) => !backendIds.has(String(post.id)) && String(post.status || "").toLowerCase() === "pending"
          );
          const mergedPosts = normalized.map((post) => {
            const previous = previousById.get(post.id);
            return {
              ...post,
              comments: post.comments ?? previous?.comments ?? [],
              comments_count: post.comments_count ?? previous?.comments_count ?? previous?.comments?.length ?? 0
            };
          });
          return [...mergedPosts, ...pendingLocal];
        });
      })
      .catch((error) => {
        console.warn("Backend posts sync failed; keeping the last available list:", error.message);
      })
      .finally(() => {
        syncInFlight.current = false;
        if (syncRequested.current) {
          syncRequested.current = false;
          window.setTimeout(() => window.dispatchEvent(new Event("refresh_posts")), 0);
        }
      });
  }, []);

  useEffect(() => {
    syncPostsFromBackend();
    window.addEventListener("refresh_posts", syncPostsFromBackend);
    const syncWhenVisible = () => {
      if (document.visibilityState === "visible") syncPostsFromBackend();
    };
    window.addEventListener("focus", syncWhenVisible);
    document.addEventListener("visibilitychange", syncWhenVisible);
    const intervalId = window.setInterval(syncWhenVisible, 30_000);
    return () => {
      window.removeEventListener("refresh_posts", syncPostsFromBackend);
      window.removeEventListener("focus", syncWhenVisible);
      document.removeEventListener("visibilitychange", syncWhenVisible);
      window.clearInterval(intervalId);
    };
  }, [syncPostsFromBackend]);

  // State bộ lọc và tìm kiếm
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Tất cả");
  const [selectedTag, setSelectedTag] = useState("");
  const [sortBy, setSortBy] = useState("newest"); // 'newest' | 'likes' | 'comments' | 'views'
  const [timeRange, setTimeRange] = useState("all"); // 'all' | 'today' | 'week' | 'month'
  const [readDuration, setReadDuration] = useState("all"); // 'all' | 'quick' | 'medium' | 'deep'
  const [currentTimestamp] = useState(() => Date.now());

  // Tự động lưu posts vào storage mỗi khi có thay đổi
  useEffect(() => {
    storage.set(STORAGE_KEYS.POSTS, posts);
  }, [posts]);

  /**
   * Lấy thông tin tác giả dựa trên authorId
   */
  const getAuthor = (authorId) => {
    if (currentUser && String(currentUser.id) === String(authorId)) return currentUser;
    const author = users.find((u) => String(u.id) === String(authorId));
    if (author) return author;
    const postWithAuthor = posts.find((p) => String(p.authorId) === String(authorId) && p.author);
    if (postWithAuthor?.author) {
      return postWithAuthor.author;
    }
    const postWithCommentAuthor = posts.find((post) =>
      (post.comments || []).some((comment) =>
        String(comment.userId ?? comment.user_id ?? comment.author_id ?? comment.author?.id) === String(authorId)
      )
    );
    const comment = postWithCommentAuthor?.comments?.find((item) =>
      String(item.userId ?? item.user_id ?? item.author_id ?? item.author?.id) === String(authorId)
    );
    if (comment?.author) return comment.author;
    return {
      id: authorId,
      name: "Tác giả IT",
      avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(authorId || "unknown")}`,
      bio: "Cộng tác viên IT Blog",
      role: "user"
    };
  };

  /**
   * Toggle Like bài viết
   */
  const toggleLike = (postId) => {
    if (!currentUser) return false;

    setPosts((prevPosts) =>
      prevPosts.map((post) => {
        if (String(post.id) !== String(postId)) return post;
        const currentLikes = Array.isArray(post.likes) ? post.likes : [];
        const alreadyLiked = currentLikes.some((id) => String(id) === String(currentUser.id));
        const updatedLikes = alreadyLiked
          ? currentLikes.filter((id) => String(id) !== String(currentUser.id))
          : [...currentLikes, currentUser.id];

        if (alreadyLiked) {
          addToast("Đã bỏ thích bài viết.", "info");
        } else {
          addToast("Đã thích bài viết! ❤️", "success");
        }

        return {
          ...post,
          likes: updatedLikes
        };
      })
    );

    api.interactions.toggleLikePost(postId).catch(() => {});
    return true;
  };

  /**
   * Toggle Bookmark (Lưu bài viết)
   */
  const toggleBookmark = (postId) => {
    if (!currentUser) return false;

    setPosts((prevPosts) =>
      prevPosts.map((post) => {
        if (String(post.id) !== String(postId)) return post;
        const currentBookmarks = Array.isArray(post.bookmarks) ? post.bookmarks : [];
        const alreadyBookmarked = currentBookmarks.some((id) => String(id) === String(currentUser.id));
        const updatedBookmarks = alreadyBookmarked
          ? currentBookmarks.filter((id) => String(id) !== String(currentUser.id))
          : [...currentBookmarks, currentUser.id];

        if (alreadyBookmarked) {
          addToast("Đã xóa khỏi danh sách đã lưu.", "info");
        } else {
          addToast("Đã lưu bài viết vào hồ sơ cá nhân! 🔖", "success");
        }

        return {
          ...post,
          bookmarks: updatedBookmarks
        };
      })
    );

    api.interactions.toggleBookmarkPost(postId).catch(() => {});
    return true;
  };

  /**
   * Đồng bộ danh sách bình luận thực tế từ backend cho một bài viết
   */
  const syncPostComments = async (postId) => {
    if (!postId) return [];
    try {
      const res = await api.comments.list(postId);
      const items = res?.items || (Array.isArray(res) ? res : []);
      if (Array.isArray(items)) {
        const formatComment = (comment, parentId = null) => {
          const author = comment.author || comment.user || {};
          const commentId = String(comment.id);
          const resolvedParentId = comment.parent_id ?? parentId;
          const formattedComment = {
            id: commentId,
            userId: String(author.id ?? comment.user_id ?? comment.author_id ?? "unknown"),
            userName: author.name || author.username || "Thành viên IT",
            userAvatar: author.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${author.id || "dev"}`,
            author,
            content: comment.content || comment.text || "",
            parentId: resolvedParentId ? String(resolvedParentId) : null,
            parent_id: resolvedParentId ? String(resolvedParentId) : null,
            likes_count: comment.likes_count || 0,
            isPinned: Boolean(comment.is_pinned),
            isAccepted: Boolean(comment.is_accepted_answer),
            createdAt: comment.created_at || new Date().toISOString()
          };
          return [
            formattedComment,
            ...(comment.replies || []).flatMap((reply) => formatComment(reply, commentId))
          ];
        };
        const formatted = items.flatMap((comment) => formatComment(comment));

        setPosts((prev) =>
          prev.map((p) =>
            String(p.id) === String(postId) || String(p.slug) === String(postId)
              ? { ...p, comments: formatted, comments_count: formatted.length }
              : p
          )
        );
        return formatted;
      }
    } catch {
      // ignore
    }
    return [];
  };

  /**
   * Thêm bình luận mới vào bài viết (hỗ trợ trả lời lồng cấp parentId)
   */
  const addComment = (postId, content, parentId = null) => {
    if (!currentUser) return false;
    const trimmed = (content || "").trim();
    if (!trimmed) return false;

    const tempId = generateId("cmt");
    const newComment = {
      id: tempId,
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar,
      content: trimmed,
      parentId: parentId,
      parent_id: parentId,
      likes_count: 0,
      createdAt: new Date().toISOString()
    };

    setPosts((prevPosts) =>
      prevPosts.map((post) => {
        if (String(post.id) !== String(postId)) return post;
        return {
          ...post,
          comments_count: (post.comments_count || (post.comments?.length || 0)) + 1,
          comments: [...(post.comments || []), newComment]
        };
      })
    );

    addToast(parentId ? "Đã gửi phản hồi bình luận! 💬" : "Đã gửi bình luận thành công! 💬", "success");
    api.comments.create(postId, { content: trimmed, parent_id: parentId })
      .then((created) => {
        if (created?.id) {
          const author = created.author || {};
          setPosts((prevPosts) =>
            prevPosts.map((post) => {
              if (String(post.id) !== String(postId)) return post;
              return {
                ...post,
                comments: (post.comments || []).map((comment) =>
                  comment.id === tempId
                    ? {
                        ...comment,
                        id: String(created.id),
                        userId: String(author.id ?? currentUser.id),
                        userName: author.name || author.username || currentUser.name,
                        userAvatar: author.avatar || currentUser.avatar,
                        author
                      }
                    : comment
                )
              };
            })
          );
        }
      })
      .catch(() => {});
    return true;
  };

  /**
   * Xóa bình luận (Dành cho tác giả bình luận hoặc Quản trị viên Admin/Moderator trực tiếp)
   */
  const deleteComment = (postId, commentId) => {
    if (!currentUser) {
      addToast("Vui lòng đăng nhập để thực hiện thao tác!", "error");
      return false;
    }

    const isSupervisor = checkIsSupervisor(currentUser);
    let permitted = false;

    setPosts((prevPosts) =>
      prevPosts.map((post) => {
        if (String(post.id) !== String(postId)) return post;
        const targetComment = (post.comments || []).find((c) => String(c.id) === String(commentId));
        const isCommentAuthor = targetComment && String(targetComment.userId) === String(currentUser.id);
        if (targetComment && !isCommentAuthor && !isSupervisor) {
          addToast("Bạn không có quyền xóa bình luận này! Chỉ người viết hoặc Ban giám sát mới có quyền xóa.", "error");
          return post;
        }

        permitted = true;
        return {
          ...post,
          comments_count: Math.max(0, (post.comments_count || (post.comments?.length || 1)) - 1),
          comments: (post.comments || []).filter(
            (c) => String(c.id) !== String(commentId) && String(c.parentId) !== String(commentId)
          )
        };
      })
    );

    if (permitted) {
      addToast(isSupervisor ? "🛡️ Ban giám sát đã xóa bình luận thành công!" : "Đã xóa bình luận.", "info");
      api.comments.delete(commentId).catch(() => {});
      return true;
    }
    return false;
  };

  /**
   * Tạo bài viết mới (Hỗ trợ status 'approved' hoặc 'pending' chờ duyệt)
   */
  const createPost = (postData) => {
    if (!currentUser) return null;

    // Đăng bài mới luôn ở trạng thái 'pending' (chờ QTV & Kiểm duyệt viên duyệt), trừ khi lưu nháp 'draft'
    const isDraft = postData.status === "draft";
    const resolvedStatus = isDraft ? "draft" : "pending";

    const newPost = {
      ...postData,
      id: generateId("post"),
      authorId: currentUser.id,
      status: resolvedStatus, // 'approved' | 'pending' | 'rejected'
      likes: [],
      bookmarks: [],
      comments: [],
      views: 1,
      readTime: postData.readTime || "4 phút đọc",
      createdAt: new Date().toISOString()
    };

    setPosts((prev) => [newPost, ...prev]);
    addToast("Đang lưu bài viết lên máy chủ...", "info");

    // Gửi lưu vào backend database
    api.posts.create({
      title: postData.title,
      category_name: postData.category,
      tags: postData.tags || ["IT"],
      cover_image: postData.coverImage || postData.cover_image || undefined,
      excerpt: postData.excerpt,
      content: postData.content,
      tech_stack_version: postData.techStackVersion,
      scheduled_at: postData.scheduledAt,
      is_deprecated: Boolean(postData.isDeprecated),
      deprecated_warning: postData.deprecatedWarning,
      status: resolvedStatus
    })
      .then((created) => {
        // DB đã có bản thật -> thay thế bản local post_xxx bằng bản thật từ DB
        if (!created?.id) {
          throw new Error("Máy chủ không trả về ID bài viết đã lưu.");
        }
        setPosts((prev) => prev.map((p) => String(p.id) === String(newPost.id) ? { ...created, authorId: currentUser.id } : p));
        addToast(
          isDraft ? "Đã lưu bản nháp vào database. 💾" : "Bài viết đã được lưu vào database và đang chờ duyệt. ⏳",
          "success"
        );
        setTimeout(() => syncPostsFromBackend(), 400);
      })
      .catch((err) => {
        console.warn("Chưa đồng bộ được bài lên máy chủ backend, giữ bản cục bộ an toàn:", err);
        addToast(`Không lưu được bài viết vào database: ${err.message}`, "error");
      });

    return newPost;
  };

  /**
   * Duyệt và xuất bản bài viết (Yêu cầu xác thực Quản trị viên Admin / Kiểm duyệt viên Moderator)
   */
  const approvePost = async (postId) => {
    if (!currentUser) {
      addToast("Vui lòng đăng nhập với quyền Ban giám sát để duyệt bài!", "error");
      return false;
    }
    if (!checkIsSupervisor(currentUser)) {
      addToast("Bạn không có quyền duyệt bài viết! Yêu cầu vai trò Admin hoặc Moderator.", "error");
      return false;
    }

    const targetPost = posts.find((p) => String(p.id) === String(postId));
    const numericId = Number(postId);

    if (Number.isInteger(numericId) && numericId > 0) {
      // 1. Bài đã có ID trong database: Cập nhật status sang 'approved'
      try {
        await api.posts.update(numericId, { status: "approved" });
        setPosts((prev) =>
          prev.map((p) => (String(p.id) === String(postId) ? { ...p, status: "approved" } : p))
        );
        addToast("Đã duyệt bài viết! AI đã tự động tạo đề trắc nghiệm bám sát nội dung vào Database! 🤖✓", "success");
      } catch (err) {
        console.warn("Lỗi khi cập nhật trạng thái bài viết lên DB:", err);
        addToast(`Không thể lưu trạng thái duyệt vào database: ${err.message}`, "error");
        return false;
      }
    } else if (targetPost) {
      // 2. Bài mới được tạo từ local/chờ duyệt: Gửi trực tiếp vào PostgreSQL Database với status 'approved'
      try {
        const created = await api.posts.create({
          title: targetPost.title,
          category_name: targetPost.category,
          tags: targetPost.tags || ["IT"],
          cover_image: targetPost.coverImage || targetPost.cover_image || undefined,
          excerpt: targetPost.excerpt || targetPost.title,
          content: targetPost.content,
          tech_stack_version: targetPost.techStackVersion,
          scheduled_at: targetPost.scheduledAt,
          is_deprecated: Boolean(targetPost.isDeprecated),
          deprecated_warning: targetPost.deprecatedWarning,
          status: "approved"
        });

        if (!created?.id) {
          throw new Error("Máy chủ không trả về ID bài viết đã lưu.");
        }
        // Cập nhật ID tạm thành ID số thật từ PostgreSQL Database
        setPosts((prev) =>
          prev.map((p) => (String(p.id) === String(postId) ? { ...created, authorId: targetPost.authorId || currentUser.id, status: "approved" } : p))
        );
        addToast("Đã lưu bài viết vào Database và AI đã tạo đề trắc nghiệm theo nội dung bài viết! 🤖✓", "success");
      } catch (err) {
        console.warn("Lỗi khi lưu bài duyệt vào DB:", err);
        addToast(`Không thể duyệt/lưu bài viết vào database: ${err.message}`, "error");
        return false;
      }
    } else {
      addToast("Không tìm thấy bài viết cần duyệt.", "error");
      return false;
    }

    setTimeout(() => syncPostsFromBackend(), 400);
    return true;
  };

  /**
   * Từ chối bài viết (Yêu cầu xác thực Quản trị viên Admin / Kiểm duyệt viên Moderator)
   */
  const rejectPost = async (postId) => {
    if (!currentUser) {
      addToast("Vui lòng đăng nhập với quyền Ban giám sát để từ chối bài!", "error");
      return false;
    }
    if (!checkIsSupervisor(currentUser)) {
      addToast("Bạn không có quyền từ chối bài viết! Yêu cầu vai trò Admin hoặc Moderator.", "error");
      return false;
    }

    const numericId = Number(postId);
    if (Number.isInteger(numericId) && numericId > 0) {
      try {
        await api.posts.update(numericId, { status: "rejected" });
        setPosts((prev) =>
          prev.map((p) => (String(p.id) === String(postId) ? { ...p, status: "rejected" } : p))
        );
      } catch (err) {
        console.warn("Lỗi từ chối bài trên DB:", err);
        addToast(`Không thể lưu trạng thái từ chối vào database: ${err.message}`, "error");
        return false;
      }
    } else {
      addToast("Không thể từ chối bài viết chưa được lưu trong database.", "error");
      return false;
    }
    addToast("Đã từ chối bài viết.", "info");
    setTimeout(() => syncPostsFromBackend(), 400);
    return true;
  };

  /**
   * Cập nhật bài viết
   */
  const updatePost = (postId, updatedData) => {
    if (!currentUser) return false;

    const isSupervisor = checkIsSupervisor(currentUser);

    setPosts((prevPosts) =>
      prevPosts.map((post) => {
        if (String(post.id) !== String(postId)) return post;
        const isAuthor = String(post.authorId || post.author_id || post.author?.id) === String(currentUser.id) ||
          (currentUser.username && (currentUser.username === post.author?.username || currentUser.username === post.authorUsername));
        if (!isAuthor && !isSupervisor) {
          addToast("Bạn không có quyền chỉnh sửa bài viết này!", "error");
          return post;
        }
        return {
          ...post,
          ...updatedData,
          updatedAt: new Date().toISOString()
        };
      })
    );

    api.posts.update(postId, {
      title: updatedData.title,
      excerpt: updatedData.excerpt,
      content: updatedData.content,
      cover_image: updatedData.coverImage,
      category_name: updatedData.category,
      tech_stack_version: updatedData.techStackVersion,
      scheduled_at: updatedData.scheduledAt,
      change_summary: updatedData.changeSummary,
      is_deprecated: updatedData.isDeprecated,
      deprecated_warning: updatedData.deprecatedWarning
    })
      .then(() => {
        addToast("Cập nhật bài viết thành công!", "success");
        syncPostsFromBackend();
      })
      .catch((err) => {
        console.warn("Lỗi cập nhật bài viết trên máy chủ:", err);
        syncPostsFromBackend();
      });

    return true;
  };

  /**
   * Xóa bài viết (Hỗ trợ Tác giả và Quản trị viên Admin/Moderator trực tiếp trên Newfeed)
   */
  const deletePost = (postId) => {
    if (!currentUser) {
      addToast("Vui lòng đăng nhập để thực hiện thao tác!", "error");
      return false;
    }
    const target = posts.find((p) => String(p.id) === String(postId));
    if (!target) return false;

    const isSupervisor = checkIsSupervisor(currentUser);
    const isAuthor = Boolean(
      currentUser && (
        String(currentUser.id) === String(target.authorId || target.author_id || target.author?.id) ||
        (currentUser.username && (currentUser.username === target.author?.username || currentUser.username === target.authorUsername))
      )
    );

    if (!isSupervisor && !isAuthor) {
      addToast("Bạn không có quyền xóa bài viết này! Thao tác chỉ dành cho tác giả hoặc Ban quản trị.", "error");
      return false;
    }

    setPosts((prev) => prev.filter((p) => String(p.id) !== String(postId)));
    api.posts.delete(postId)
      .then(() => {
        addToast(isSupervisor && !isAuthor ? "🛡️ Ban giám sát đã xóa bài viết trực tiếp thành công!" : "Đã xóa bài viết thành công! 🗑️", "info");
        syncPostsFromBackend();
      })
      .catch((err) => {
        console.warn("Lỗi xóa bài viết trên máy chủ:", err);
        syncPostsFromBackend();
      });
    return true;
  };

  /**
   * Ghim / Bỏ ghim bài viết lên đầu Newfeed (Quyền Admin)
   */
  const togglePinPost = (postId) => {
    if (!currentUser) return false;
    if (!checkIsSupervisor(currentUser)) {
      addToast("Chỉ Ban giám sát / Quản trị viên mới có quyền ghim bài viết lên đầu Newfeed!", "error");
      return false;
    }

    setPosts((prev) =>
      prev.map((p) => {
        if (String(p.id) !== String(postId)) return p;
        const nextPin = !p.isPinned;
        if (nextPin) {
          addToast("📌 Đã ghim bài viết lên đầu Newfeed thành công!", "success");
        } else {
          addToast("Đã bỏ ghim bài viết khỏi đầu Newfeed.", "info");
        }
        return { ...p, isPinned: nextPin };
      })
    );
    return true;
  };

  /**
   * Ghi nhận và đồng bộ lượt xem thật cho bài viết từ CSDL PostgreSQL
   * Sử dụng khoảng giãn cách (cooldown 15 giây) để chống spam khi cuộn trang hay re-render,
   * nhưng đảm bảo mỗi lần độc giả mở bài viết vào xem sẽ được cộng lượt xem thật vào CSDL.
   */
  const incrementViews = useCallback((postId) => {
    if (!postId) return;
    const sessionKey = `last_viewed_ts_${postId}`;
    const lastViewed = typeof window !== "undefined" && window.sessionStorage?.getItem(sessionKey);
    const now = Date.now();
    const cooldownMs = 15000; // 15 giây chống spam liên tục trong cùng 1 lần đọc

    const isRecentView = lastViewed && (now - parseInt(lastViewed, 10)) < cooldownMs;

    if (!isRecentView) {
      if (typeof window !== "undefined" && window.sessionStorage) {
        window.sessionStorage.setItem(sessionKey, String(now));
      }
      // Gọi API backend với track_view=true để ghi nhận lượt xem thật vào cơ sở dữ liệu
      api.posts.get(postId, { track_view: "true" })
        .then((updatedPost) => {
          if (updatedPost && typeof updatedPost.views === "number") {
            setPosts((prev) =>
              prev.map((p) => (String(p.id) === String(postId) ? { ...p, views: updatedPost.views } : p))
            );
          }
        })
        .catch(() => {
          // Fallback cục bộ chỉ khi backend không phản hồi
          setPosts((prev) =>
            prev.map((p) => (String(p.id) === String(postId) ? { ...p, views: (p.views || 0) + 1 } : p))
          );
        });
    } else {
      // Trong thời gian cooldown (ví dụ đang lướt đọc bài): đồng bộ số lượt xem thật từ CSDL mà không tăng thêm
      api.posts.get(postId, { track_view: "false" })
        .then((freshPost) => {
          if (freshPost && typeof freshPost.views === "number") {
            setPosts((prev) =>
              prev.map((p) => (String(p.id) === String(postId) ? { ...p, views: freshPost.views } : p))
            );
          }
        })
        .catch(() => {});
    }
  }, []);

  // Danh sách phân loại theo trạng thái duyệt
  const pendingPosts = useMemo(
    () => posts.filter((p) => p.status === "pending"),
    [posts]
  );
  const approvedPosts = useMemo(
    () => posts.filter((p) => !p.status || p.status === "approved"),
    [posts]
  );
  const rejectedPosts = useMemo(
    () => posts.filter((p) => p.status === "rejected"),
    [posts]
  );

  /**
   * Chuỗi xử lý lọc danh sách bài viết công khai trên trang chủ (chỉ hiện bài đã duyệt)
   */
  const filteredPosts = useMemo(() => {
    let result = posts.filter((p) => !p.status || p.status === "approved");

    // 1. Lọc theo từ khóa tìm kiếm (Search Query)
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.excerpt?.toLowerCase().includes(q) ||
          p.tags?.some((t) => t.toLowerCase().includes(q))
      );
    }

    // 2. Lọc theo Danh mục (Category)
    if (selectedCategory && selectedCategory !== "Tất cả") {
      result = result.filter((p) => p.category === selectedCategory);
    }

    // 3. Lọc theo Tag
    if (selectedTag) {
      result = result.filter((p) => p.tags?.includes(selectedTag));
    }

    // 4. Lọc theo Khoảng thời gian xuất bản (Time Range)
    if (timeRange && timeRange !== "all") {
      const now = currentTimestamp;
      result = result.filter((p) => {
        const postTime = new Date(p.createdAt).getTime();
        if (isNaN(postTime)) return true;
        const diffMs = now - postTime;
        if (timeRange === "today") return diffMs <= 24 * 60 * 60 * 1000;
        if (timeRange === "week") return diffMs <= 7 * 24 * 60 * 60 * 1000;
        if (timeRange === "month") return diffMs <= 30 * 24 * 60 * 60 * 1000;
        return true;
      });
    }

    // 5. Lọc theo Thời lượng đọc kỹ thuật (Reading Duration)
    if (readDuration && readDuration !== "all") {
      result = result.filter((p) => {
        const match = String(p.readTime || "5").match(/\d+/);
        const mins = match ? parseInt(match[0], 10) : 5;
        if (readDuration === "quick") return mins < 3;
        if (readDuration === "medium") return mins >= 3 && mins <= 7;
        if (readDuration === "deep") return mins > 7;
        return true;
      });
    }

    // 6. Sắp xếp (Sort)
    if (sortBy === "likes") {
      result.sort((a, b) => {
        const countA = a.likes_count ?? (Array.isArray(a.likes) ? a.likes.length : 0);
        const countB = b.likes_count ?? (Array.isArray(b.likes) ? b.likes.length : 0);
        return countB - countA;
      });
    } else if (sortBy === "comments") {
      result.sort((a, b) => {
        const countA = a.comments_count ?? (Array.isArray(a.comments) ? a.comments.length : 0);
        const countB = b.comments_count ?? (Array.isArray(b.comments) ? b.comments.length : 0);
        return countB - countA;
      });
    } else if (sortBy === "views") {
      result.sort((a, b) => (b.views || 0) - (a.views || 0));
    } else {
      // Mặc định: Mới nhất
      result.sort((a, b) => {
        const dateA = new Date(a.createdAt || a.created_at || a.date || 0);
        const dateB = new Date(b.createdAt || b.created_at || b.date || 0);
        return dateB - dateA;
      });
    }

    // Luôn ưu tiên bài viết được Admin Ghim (isPinned) lên đầu Newfeed
    result.sort((a, b) => (b.isPinned ? 1 : 0) - (a.isPinned ? 1 : 0));

    return result;
  }, [posts, searchQuery, selectedCategory, selectedTag, sortBy, timeRange, readDuration, currentTimestamp]);

  const resetFilters = () => {
    setSearchQuery("");
    setSelectedCategory("Tất cả");
    setSelectedTag("");
    setSortBy("newest");
    setTimeRange("all");
    setReadDuration("all");
  };

  return (
    <BlogContext.Provider
      value={{
        posts,
        filteredPosts,
        pendingPosts,
        approvedPosts,
        rejectedPosts,
        searchQuery,
        setSearchQuery,
        selectedCategory,
        setSelectedCategory,
        selectedTag,
        setSelectedTag,
        sortBy,
        setSortBy,
        timeRange,
        setTimeRange,
        readDuration,
        setReadDuration,
        resetFilters,
        getAuthor,
        toggleLike,
        toggleBookmark,
        addComment,
        deleteComment,
        syncPostComments,
        createPost,
        updatePost,
        deletePost,
        togglePinPost,
        incrementViews,
        approvePost,
        rejectPost,
        refreshPosts: syncPostsFromBackend
      }}
    >
      {children}
    </BlogContext.Provider>
  );
}

export function useBlog() {
  const context = useContext(BlogContext);
  if (!context) {
    throw new Error("useBlog must be used within a BlogProvider");
  }
  return context;
}
